# Broadcast-music-in-vk-status
### Вечная трансляция музыки в статус вк

**Как запустить?**

1. Зайдите в файл ***config.json*** и впишите туда свой токен и аудио (Подробнее в примечаниях)
2. Запустите файл ***main.py***

Команда для запуска: `python main.py`

**Примечания**

  1) Получить токен можно [здесь](https://oauth.vk.com/authorize?client_id=6146827&scope=1073737727&redirect_uri=https://oauth.vk.com/blank.html&display=page&response_type=token&revoke=1) (токен от приложения vk me)
  
  2) Идентификатор аудиозаписи, которая будет отображаться в статусе, в формате owner_id_audio_id. Например, 1_230210020.
